<?php
     session_start();
     if( isset( $_SESSION["id"] ) ){
        $varid = $_SESSION["id"];
        $varfName = $_SESSION["fname"];
        $varlName = $_SESSION["lname"];  
        $varPassword = $_SESSION["pass"];  
        
     }
    else{
        
        header("location: http://gonzalogtz.com/Content/FinalWeb/");
    }

?>



<!DOCTYPE html>
<html lang="en">

<head>
        <link rel="stylesheet" type="text/css" href="css/syleGameScreen.css" />
        <script src="https://use.fontawesome.com/816557fe7b.js"></script>
    
        <!-- Fonts importadas //-->
        <link href='https://fonts.googleapis.com/css?family=Fredericka+the+Great' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Monoton' rel='stylesheet' type='text/css'>
    
        <link href="https://fonts.googleapis.com/css?family=Cinzel" rel="stylesheet">   
    
    
    
    
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.2/css/bootstrap.min.css" integrity="sha384-y3tfxAZXuh4HwSYylfB+J125MxIs6mR5FOHamPBG064zB+AFeWH94NdvaCBm8qnd" crossorigin="anonymous">
        
    
    </head>

<body>

       
        <div id="container-fluid"> 
          
        
            

            
            
            <div id="container">
                <div id="sidebar">
                    <ul>
                        <li id="userlogin"><?php echo $varid  ?></li>
                        <li id="puntosLabel">Points</li>
                        <li id="puntuaje">0</li>
                        
                        
                        
                        
                        <li id="timeleftLabel">Time Left</li>
                        <li id="timeleft"></li>
                        
                        <div id="btnside">
                        <li class="buttonsSidebar"><a class="btn btn-blue startGame2" id="botonPlay">Play!</a></li>        
                        <li class="buttonsSidebar"><a class="btn btn-blue startGame2" id="botonProf">Profile</a></li>
                        <li class="buttonsSidebar"><a class="btn btn-blue startGame2" id="botonHigh">HighScores</a></li>
                        
                        <li class="buttonsSidebar"><a class="btn btn-blue startGame2" id="seachbutton">Search</a></li>
                        
                        <li class="buttonsSidebar"><a class="btn btn-blue startGame2" id="contactmeLab">Contact Me</a></li>
                            
                        <li class="buttonsSidebar"><a class="btn btn-blue startGame2" id="logoutbutton">LogOut</a></li>
                            
                        </div>
                    
                        
                     

                        
                        
                        
                    </ul>
                </div>
                
                <div id="game">
                    
                    
                    <div id="pantallaPrincipal" class="center">
                        <h1 id="startGameLabel"> How much you know about <span id="green">Me</span>xi<span id="red">co</span>? <br>Choose a Category!</h1>
                        
                        <a class="btn btn-blue startGame" id="startGameOld"  >Past</a> 
                        <a class="btn btn-blue startGame" id="startGameRecent" >Present</a> 
                        
                        
                    </div>
                    <div id="juegoPreguntas" >
                        
                        <div class="pregunta" id="0"></div>
                       
                        
                        
                        <button class="button opcion " id="1"></button><br>
                        <button class="button opcion " id="2"></button><br>
                        <button class="button opcion " id="3"></button><br>
                        <button class="button opcion" id="4"></button>
                        
                    
                    
                    
                    
                    </div>
                    
                    <div id="subirPuntaje" class="center">
                        <h1 id="startGameLabel">Puntaje Final </h1>
                        <h2 id="puntajeFinal"></h2>
                        <div class="form-group">
                            
                            <a class="btn btn-blue " id="submitScore" >Submit</a> 
                        </div>   
                        
                    </div>
                    
                    
                        
                        <table class="table "id="tablaPuntajes">
                            <div id="highlab">HighScores</div> 
                            
                        <thead >    
                          <tr >
                            <th>Place</th>
                            <th>Name</th>
                            <th>Score</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr id="1" class="puntaje">
                            <th scope="row">1</th>
                          </tr>
                          <tr id="2" class="puntaje">
                            <th scope="row">2</th>
                          </tr>
                          <tr id="3" class="puntaje">
                            <th scope="row">3</th>
                          </tr>
                          <tr id="4" class="puntaje">
                            <th scope="row">4</th>
                          </tr>
                          <tr id="5" class="puntaje">
                            <th scope="row">5</th>
                          </tr>
                        <tr id="6" class="puntaje">
                            <th scope="row">6</th>
                          </tr>
                        <tr id="7" class="puntaje">
                            <th scope="row">7</th>
                          </tr>
                        <tr id="8" class="puntaje">
                            <th scope="row">8</th>
                          </tr>
                        <tr id="9" class="puntaje">
                            <th scope="row">9</th>
                          </tr>
                        <tr id="10" class="puntaje">
                            <th scope="row">10</th>
                          </tr>
                        </tbody>
                      </table>
                    
                    
                    <div id="profile" >
                        <h1 id="titlemessegeProfile">Profile</h1>
                       
                        <br>
                        <label class="labelProfile">Firt Name</label><br>
                        <input  id="fNamep" type="text" class="profileText" ><br>
                        <label class="labelProfile">Last Name</label><br>
                        <input  id="lNamep" type="text" class="profileText" ><br>
                        <label class="labelProfile">UserName</label><br>
                        <input  id="userNamep" type="text" class="profileText" ><br>
                        <label class="labelProfile">Password</label><br>
                        <input  id="passwrdp" type="text" class="profileText" ><br>
                        <input id="savebutton" type="button" class="btn btn-primary" value="Save">
                        <div id="NoerrorSearch"class="alert alert-success"></div>
                        <div id="errorSearch"class="alert alert-danger"></div>
                        
                    
                    </div>
                    
                    
                    <div id="comment" >
                        <h1 id="titlemessege">Send me a messege!</h1>
                        <h5 id="subtitlemessege">Tell me if a question is wrong or write me a question you would like to see. </h5>



                        <br>
                        
                        <input  id="mail" type="text" placeholder="Email@example.com" ><br>
                        
                        <textarea class="" id="comentario"></textarea><br>
                        <input id="subcomment" type="button" class="btn btn-primary" value="Submit">
                        <div id="NoerrorSearch1"class="alert alert-success"></div>
                        <div id="errorSearch1"class="alert alert-danger"></div>
                    
                    </div>
                    
                    
                    <div id="search" >
                        <h1 id="titlemessege2">Looking for a question?</h1>
                        <h5 id="subtitlemessege2">Type the id of the question you are looking for.</h5>

                        <br>
                        
                        <input  id="idSearch" type="text" placeholder="#num" ><br>
                        
                        
                        <input id="subSearch" type="button" class="btn btn-primary" value="Submit">
                        <div id="errorSearch2" class="alert alert-danger"></div>
                    
                    </div>
                    
                    <div id="juegoPreguntasSearch" >
                        
                        <div class="pregunta1" id="00"></div>
                       
                        
                        
                        <button class="button opcion1 " id="1"></button><br>
                        <button class="button opcion1 " id="2"></button><br>
                        <button class="button opcion1 " id="3"></button><br>
                        <button class="button opcion1" id="4"></button>
                        
                    
                    
                    
                    
                    </div>
                    
                    
                    
                    
                </div>
            </div>
            
        </div>
    
    
      
        

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.0.0/jquery.min.js" integrity="sha384-THPy051/pYDQGanwU6poAc/hOdQxjnOEXzbT+OuUAFqNqFjL+4IGLBgCJC3ZOShY" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.2.0/js/tether.min.js" integrity="sha384-Plbmg8JY28KFelvJVai01l8WyZzrYWG825m+cZ0eDDS1f7d/js6ikvy1+X+guPIB" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.3/js/bootstrap.min.js" integrity="sha384-ux8v3A6CPtOTqOzMKiuo3d/DomGaaClxFYdCu2HPMBEkf6x2xiDyJ7gkXU0MWwaD" crossorigin="anonymous"></script>
        <script type="text/javascript" src="javascript/jquery.js"></script>
    

</body>

</html>
