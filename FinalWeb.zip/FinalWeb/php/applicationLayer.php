<?php

header('Content-type: application/json');
require_once __DIR__ . "/dataLayer.php";

$action = $_POST["action"];

switch($action){
    case "OPCIONMULTIPLE":
        opcionMultiple();
        break;
        
    case "OBTENERPUNTAJE":
        obtenerPuntaje();
        break;
   case "REGISTRARPUNTAJE":
        registrarPuntaje();
        break;
        
    case "LOGIN" : login();
        break;     
    
    case "REGISTER" : Register();
        break;  
        
    case "PROFILE" : profile();
        break;
        
    case "SAVE" : save();
        break;  
    
    case "MAIL" : email2();
        break; 
        
    case "OPCIONMULTIPLESEARCH" : opcionMultipleSearch();
        break;   
   
    case "LOGOUT" : logout();
        break;    
}

function logout(){
    session_start();
    
    session_unset();
    session_destroy();
    
    
    echo json_encode(array("message" => "Welcome Back!"));
}


function email2(){
     
    $email = $_POST["email"];
    $msg = $_POST["comentario"];
    
    $msg = wordwrap($msg,70);
    mail("gonzalogtzs94@gmail.com",$email,$msg);
    
    echo json_encode(array("message" => "Welcome Back!"));
}

function save(){
    $userName = $_POST["username"];
    $fName = $_POST["fname"];
    $lName = $_POST["lname"];
    
    $userNameOld = $_POST["old"];
    
    $paswrd = encryptPassword2();
    
    $result = saveAttempt($userName,$userNameOld,$fName,$lName,$paswrd);
    
    if($result["status"] == "SUCCESS"){ 
        session_start();
			    
        $_SESSION["id"] = $userName;
        
       echo json_encode(array("message" => "Welcome Back!"));
    }   
    
    else{
    
        header("HTTP/1.1 406". $result["status"]);

        die($result["status"]);   
    }
    
}




function profile(){
    $userName = $_POST["username"];
    $result = attemptProfile($userName);
    
    
    if($result["status"] == "SUCCESS"){
        echo json_encode(array("fName" => $result["firstName"], "userName" => $result["username"], "passwrd" => decryptPassword($result["password"]), "lName" => $result["lastName"]        ));
        
       
    }   
    
    else{
    
        header("HTTP/1.1 406". $result["status"]);

        die($result["status"]);   
    }
    
    
    
    
}

function login(){
    
    $userName = $_POST["username"];
    
  
    
    $result = attempLogin($userName);
    
    
    if($result["status"] == "SUCCESS"){
            $password = $_POST["password"];
              
            $decryptedPassword = decryptPassword($result['password']);
           
            
            
        
            if ($decryptedPassword === $password)
            {	
                    
                
                    session_start();
			    
                    $_SESSION["id"] = $userName;
                    echo json_encode(array("message" => "Welcome Back!"));

            }
            else{

                    header("HTTP/1.1 406". "Username or password wrong!");

                    die("Username or password wrong!");   
            }
        
        
        
       
        }
    else{

                    header("HTTP/1.1 406". $result["status"]);

                    die($result["status"]);   
        }
    
    
    
    
    
    
}

function decryptPassword($password)
{
    
      
    
		$key = pack('H*', "bcb04b7e103a05afe34763051cef08bc55abe029fdebae5e1d417e2ffb2a00a3");
	    
	    $iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC);
    	
	    $ciphertext_dec = base64_decode($password);
	    $iv_dec = substr($ciphertext_dec, 0, $iv_size);
	    $ciphertext_dec = substr($ciphertext_dec, $iv_size);

	    $password = mcrypt_decrypt(MCRYPT_RIJNDAEL_128, $key, $ciphertext_dec, MCRYPT_MODE_CBC, $iv_dec);
	   	
	   	
	   	$count = 0;
	   	$length = strlen($password);

	    for ($i = $length - 1; $i >= 0; $i --)
	    {
	    	if (ord($password{$i}) === 0)
	    	{
	    		$count ++;
	    	}
	    }

	    $password = substr($password, 0,  $length - $count); 

	    return $password;
}



function encryptPassword()
{
		$userPassword = $_POST["userPasswordRegister"];

	    $key = pack('H*', "bcb04b7e103a05afe34763051cef08bc55abe029fdebae5e1d417e2ffb2a00a3");
	    $key_size =  strlen($key);
	    
	    $plaintext = $userPassword;

	    $iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC);
	    $iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
	    
	    $ciphertext = mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $key, $plaintext, MCRYPT_MODE_CBC, $iv);
	    $ciphertext = $iv . $ciphertext;
	    
	    $userPassword = base64_encode($ciphertext);

	    return $userPassword;
}

function encryptPassword2()
{
		$userPassword = $_POST["userPassword"];

	    $key = pack('H*', "bcb04b7e103a05afe34763051cef08bc55abe029fdebae5e1d417e2ffb2a00a3");
	    $key_size =  strlen($key);
	    
	    $plaintext = $userPassword;

	    $iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC);
	    $iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
	    
	    $ciphertext = mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $key, $plaintext, MCRYPT_MODE_CBC, $iv);
	    $ciphertext = $iv . $ciphertext;
	    
	    $userPassword = base64_encode($ciphertext);

	    return $userPassword;
}


function Register(){
    $userName = $_POST["usernameRegister"];
    $firstName = $_POST["fname"];
			
    $lastName = $_POST["lname"];
	
    $userPassword = encryptPassword();
    
    
    
    $result = attemptRegister($userName, $userPassword, $firstName, $lastName );
    
    if($result["status"] == "SUCCESS"){
        echo json_encode(array("message" => "Welcome!"));
        
       
    }   
    
    else{
    
        header("HTTP/1.1 406". $result["status"]);

        die($result["status"]);   
    }
    
    
    
}

function opcionMultipleSearch(){
    $question = $_POST["question"];
   // echo $category;
    $result = preguntasOpcionMultipleSearch($question);

    if ($result["status"] != "ERROR"){
        
        echo json_encode($result);
    }
    else {
        header('HTTP/1.1 500'  . $result["status"]);
		die($result["status"]);
    }
}


function opcionMultiple(){
    $category = $_POST["category"];
   // echo $category;
    $result = preguntasOpcionMultiple($category);

    if ($result["status"] != "ERROR"){
        
        echo json_encode($result);
    }
    else {
        header('HTTP/1.1 500'  . $result["status"]);
		die($result["status"]);
    }
}


function obtenerPuntaje(){
    $result = obtenerPuntuacionAlta();

    if ($result["status"] != "ERROR"){
        echo json_encode($result);
    }
    else {
        header('HTTP/1.1 400'  . $result["status"]);
		die($result["status"]);
    }
}

function registrarPuntaje(){
    $puntaje = $_POST["puntaje"];
    $nombre = $_POST["nombre"];

    $result = registrarPuntuacionAlta($puntaje, $nombre);

    if ($result["status"] != "ERROR"){
        echo json_encode($result);
    }
    else {
        header('HTTP/1.1 500'  . $result["status"]);
		die($result["status"]);
    }
}









?>
