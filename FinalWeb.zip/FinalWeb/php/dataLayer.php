<?php
	header('Accept: application/json');
	header('Content-type: application/json');

    function connectionToDataBase(){
        $servername = "217.199.187.196";
        $username = "cl55-mexico";
        $password = "gonzalogtz0";
        $dbname = "cl55-mexico";

        $conn = new mysqli($servername, $username, $password, $dbname);
        $conn->set_charset("utf8");
        if ($conn->connect_error){
            return null;
        }
        else{
            return $conn;
        }
    }
    
    function saveAttempt($userName,$userNameOld,$fName,$lName,$paswrd){
        $conn = connectionToDataBase();  
        if($conn != nulll){
            if($userName == $userNameOld ){
                $sql = "SELECT fName, lName FROM USERS WHERE userName = ''";

                $result = $conn->query($sql);
            }
            else{
               $sql = "SELECT fName, lName FROM USERS WHERE userName = '$userName'";

                $result = $conn->query($sql); 
            }
            

            if ($result->num_rows > 0) {
                $conn -> close();
                return array("status" => "User already exists!");
            }

            else{

                $sql = "UPDATE USERS SET userName = '$userName', passwrd = '$paswrd' , fName = '$fName' , lName = '$lName' WHERE userName = '$userNameOld';";
            

                $conn->query($sql);
                return array("status" => "SUCCESS");


            }
            
            
            
                
            
            
        }
        else{
            $conn -> close();
            return array("status" => "CONNECTION WITH DB WENT WRONG");
        }
    }

    function attemptProfile($userName){
        $conn = connectionToDataBase();
        if($conn != nulll){
            $sql = "SELECT fName, lName, passwrd, userName FROM USERS WHERE userName = '$userName'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                  return array("firstName"=>$row["fName"],"username"=>$row["userName"],"password"=>$row["passwrd"], "lastName"=>$row["lName"], "status" => "SUCCESS"); 
                }
            }
            else{
                $conn -> close();
                return array("status" => "What!");
            }
        }
        else{
            $conn -> close();
            return array("status" => "CONNECTION WITH DB WENT WRONG");
        }
    }




    function attempLogin($userName){
        $conn = connectionToDataBase();

        if($conn != nulll){

            $sql = "SELECT fName, lName, passwrd, userName FROM USERS WHERE userName = '$userName'";

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {






                while ($row = $result->fetch_assoc()) {

                    return array("firstName"=>$row["fName"],"username"=>$row["userName"],"password"=>$row["passwrd"], "lastName"=>$row["lName"], "status" => "SUCCESS"); 


                }


            }
            else{
                $conn -> close();
                return array("status" => "The username or password is wrong!");
            }




        }

        else{
            $conn -> close();
            return array("status" => "CONNECTION WITH DB WENT WRONG");

        }



    }

    function attemptRegister($userName, $userPassword, $firstName, $lastName )
    {
    
        $conn = connectionToDataBase();

        if($conn != nulll){

            $sql = "SELECT fName, lName FROM USERS WHERE userName = '$userName'";

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $conn -> close();
                return array("status" => "User already exists!");
            }

            else{

                $sql = "INSERT INTO USERS(fName, lName, userName, passwrd) VALUES ('$firstName', '$lastName', '$userName', '$userPassword');";

                $conn->query($sql);

                

                return array("status" => "SUCCESS");


            }





        }

        else{
            $conn -> close();
            return array("status" => "CONNECTION WITH DB WENT WRONG");

        }


    }




    function obtenerPuntuacionAlta(){
        $conn = connectionToDataBase();

        if ($conn != null){
            $sql = "SELECT nombre, puntaje FROM PUNTAJES ORDER BY puntaje DESC LIMIT 10";

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $response = new ArrayObject();
                while ($row = $result->fetch_assoc()) {
                    $response->append(array("nombre"=>$row["nombre"], "puntaje"=>$row["puntaje"]));
                }
            }

            $conn -> close();
            return $response;
        }
        else {
            $conn -> close();
            return array("status" => "ERROR");
        }                
    }

    function registrarPuntuacionAlta($puntaje, $nombre){
        $conn = connectionToDataBase();

        if ($conn != null){
            $sql = "INSERT INTO PUNTAJES(nombre, puntaje, id) VALUES ('$nombre', '$puntaje', 0)";

            if (mysqli_query($conn, $sql)){
                    $conn -> close();
                    return array("status" => "SUCCESS");
                }
                else{
                    $conn -> close();
                    return array("status" => "ERROR");
                }
        }
        else {
            $conn -> close();
            return array("status" => "ERROR");
        }   
    }


    function preguntasOpcionMultiple($category){
        $conn = connectionToDataBase();

        if ($conn != null){
            
            if($category == "Recent"){
                $sql = "SELECT pregunta, respuesta, opcionB, opcionC, opcionD FROM PREGUNTAS WHERE opcionMultiple = 1 ORDER BY RAND() LIMIT 5";    
            }
            else{
                $sql = "SELECT pregunta, respuesta, opcionB, opcionC, opcionD FROM PREGUNTAS WHERE opcionMultiple = 2 ORDER BY RAND() LIMIT 5";
            }

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $response = new ArrayObject();
                $i = 0;
                while ($row = $result->fetch_assoc()) {
                    $response->append(array("pregunta"=>$row["pregunta"], "respuesta"=>$row["respuesta"], 
                        "opcionB"=>$row["opcionB"], "opcionC"=>$row["opcionC"], "opcionD"=>$row["opcionD"], "id"=>$i));
                    $i = $i + 1;
                }
            }

            $conn -> close();
            return $response;
        }
        else {
            $conn -> close();
            return array("status" => "ERROR");
        }                
    }




    function preguntasOpcionMultipleSearch($question){
        $conn = connectionToDataBase();

        if ($conn != null){
            
            $sql = "SELECT pregunta, respuesta, opcionB, opcionC, opcionD FROM PREGUNTAS WHERE search = '$question'";

            $result = $conn->query($sql);
            
            if ($result->num_rows > 0) {
                $response = new ArrayObject();
                $i = 0;
                while ($row = $result->fetch_assoc()) {
                    $response->append(array("pregunta"=>$row["pregunta"], "respuesta"=>$row["respuesta"], 
                        "opcionB"=>$row["opcionB"], "opcionC"=>$row["opcionC"], "opcionD"=>$row["opcionD"], "id"=>$i));
                    $i = $i + 1;
                }
            }

            $conn -> close();
            return $response;
        }
        else {
            $conn -> close();
            return array("status" => "ERROR");
        }                
    }

    
    
?>