var timerId;
var timeLeft;







function timerJuego(iTiempo) {
    
    
    timeLeft = iTiempo;
    timerId = setInterval(countdown, 1000);
    function countdown() {
        if (timeLeft == 0  ) {
            timeLeft == 0;
            $("#timeleft").html(timeLeft);
            clearTimeout(timerId);
        }
        else {
            $("#timeleft").html(timeLeft);
            timeLeft--;
        }
    }
}

function resetColor(){
    $('.opcion').each(function () {
        
        $(this).css("background-color", "#699DB6");
            
        
    });
    $('.opcion1').each(function () {
        
        $(this).css("background-color", "#699DB6");
            
        
    });
}



function juegoAcabado(){
        $("#timeleft").hide();
        $("#juegoPreguntas").hide();
        $("#pantallaPrincipal").hide();
        $("#juegoPreguntas").hide();
        $("#startGameLabel2").hide();
        $("#subirPuntaje").show();
        $("#puntajeFinal").html($("#puntuaje").html());
        
}





$(".startGame").click(function () {
    clearTimeout(timerId);
    var cat = $(this).html();
    $("#timeleft").show();
    timerJuego(15);
        
    $("#juegoPreguntas").show();
    $("#pantallaPrincipal").hide();
    
    
    var listaPreguntas;
    var preguntaActual = 0;
    var jsonData = {
        "action": "OPCIONMULTIPLE",
        "category": cat
    };
    $.ajax({
        url: "php/applicationLayer.php"
        , type: "POST"
        , data: jsonData
        , dataType: "json"
        , contentType: "application/x-www-form-urlencoded"
        , success: function (jsonResponse) {
            listaPreguntas = jsonResponse;
            console.log(listaPreguntas);
            llenaPregunta();
        }
        , error: function (errorMessage) {
            console.log(errorMessage);
        }
    });

    function llenaPregunta() {
        reiniciaOpciones();
        $("#0").html(listaPreguntas[preguntaActual]["pregunta"]);
        var opciones = [listaPreguntas[preguntaActual]["respuesta"], listaPreguntas[preguntaActual]["opcionB"]
                                , listaPreguntas[preguntaActual]["opcionC"], listaPreguntas[preguntaActual]["opcionD"]];
        opciones = shuffleArray(opciones);
        var i = 0;
        $(".opcion").each(function () {
            if (opciones[i] != "N/A") {
                $(this).html(opciones[i]);
                $(this).show();
            }
            i++;
        });
    }
    $(".opcion").on("click", function () {
        var puntosAnteriores = Number($("#puntuaje").html());
            
            
        var tiempoRestante = Number($("#timeleft").html())
        
        
        if ($(this).html() == listaPreguntas[preguntaActual]["respuesta"]) {    
           
            puntosAnteriores = puntosAnteriores + (tiempoRestante * 2);
            
            $("#puntuaje").html(puntosAnteriores); 
            if (preguntaActual < 4) {
                console.log("success!");
                clearTimeout(timerId);
                $("#timeleft").show();
                timerJuego(15);
                preguntaActual++;
                resetColor();
                llenaPregunta();
            }
            else {
                console.log("Se acabo");
                clearTimeout(timerId);
                juegoAcabado();
                //$("#pantallaPrincipal").show();
                
                
            }
        }
        else {
            $('.opcion').each(function () {
               
                if ($(this).html() == listaPreguntas[preguntaActual]["respuesta"]) {
                    $(this).css("background-color", "#61c76d");
                   
                }
            });
            
            
            
            $("#timeleft").html("");
            
            clearTimeout(timerId);
            
            $("#timeleft").hide();
            
            $(this).css("background-color", "#db5858");
        }
    });

    function reiniciaOpciones() {
        $(".opcion").each(function () {
            $(this).hide();
        });
    }
   
    function shuffleArray(a) {
        var i, t, j;
        for (i = a.length - 1; i > 0; i -= 1) {
            t = a[i];
            j = Math.floor(Math.random() * (i + 1));
            a[i] = a[j];
            a[j] = t;
        }
        return a;
    }
});



$(document).ready(function () {
    var jsonData = {
        "action": "OBTENERPUNTAJE"
    };

    $.ajax({
        url: "php/applicationLayer.php",
        type: "POST",
        data: jsonData,
        dataType: "json",
        contentType: "application/x-www-form-urlencoded",
        success: function (jsonResponse) {
            console.log(jsonResponse);
            llenaPuntajes(jsonResponse);
        },
        error: function (errorMessage) {
            console.log(errorMessage);
        }
    });

    function llenaPuntajes(puntajes) {
        var i = 0;
        $(".puntaje").each(function () {
            $(this).append("<td>" + puntajes[i]["nombre"] + "</td>");
            $(this).append("<td>" + puntajes[i]["puntaje"] + "</td>");

            i++;
        });

    }
});




$("#submitScore").on("click", function () {

        if ($("#submitName").val() == "") {
            $("#errorMessage").show();
            $("#errorMessage").html("No olvides poner tu nombre!");
        }
        else {
            var jsonData2 = {
                "action": "REGISTRARPUNTAJE",
                "puntaje": $("#puntajeFinal").html(),
                "nombre": $("#userlogin").html()
            };

            $.ajax({
                url: "php/applicationLayer.php",
                type: "POST",
                data: jsonData2,
                dataType: "json",
                contentType: "application/x-www-form-urlencoded",
                success: function (jsonResponse) {
                    console.log(jsonResponse);
                    location.reload();
                },
                error: function (errorMessage) {
                    console.log(errorMessage);
                }
            });

            regresarIndex();
        }

});

$("#signInButton").click(function () {
  
    var jsonData = {
        "username": $("#inEmail").val()
        , "password": $("#inPassword").val(),
        "action" : "LOGIN"
    };
    $.ajax({
        url: "php/applicationLayer.php"
        , type: "POST"
        , data: jsonData
        , dataType: "json"
        , contentType: "application/x-www-form-urlencoded"
        , success: function (jsonResponse) {
            
            window.location.href = "http://gonzalogtz.com/Content/FinalWeb/gameScreen.php"
            
            
        }
        , error: function (errorMessage) {
            
            $("#errorMessage4").show();
            $("#errorMessage4").html("User or password incorrect!");
        }
    });
    
    
    
    
    
    
    
    
});

 

$("#savebutton").click(function () {
        
        //$("#errorMessage").show();
        
          $("#NoerrorSearch").hide();  
          $("#errorSearch").hide();
    
    if($("#userNamep").val() == "" | $("#passwrdp").val() == "" | $("#fNamep").val() == "" | $("#lNamep").val() == ""  ){
        $("#errorSearch").show();
        $("#errorSearch").html("Please fill all the information.");
    }
    else{
        
        var jsonData = {
        "old": $("#userlogin").html(),
        "action" : "SAVE",
        "username" : $("#userNamep").val(),
        "userPassword" : $("#passwrdp").val(),
        "fname" : $("#fNamep").val(),
        "lname" : $("#lNamep").val(),
        
            
    };
    $.ajax({
        url: "php/applicationLayer.php"
        , type: "POST"
        , data: jsonData
        , dataType: "json"
        , contentType: "application/x-www-form-urlencoded"
        , success: function (jsonResponse) {
            
            $("#userlogin").html($("#userNamep").val())
                $("#NoerrorSearch").show();
                $("#NoerrorSearch").html("Saved!");
            
        }
        , error: function (errorMessage) {
            
             $("#errorSearch").show();
            $("#errorSearch").html("Username already exists.");
        }
    });
        
    }
  
    
});




$("#botonProf").click(function () {
        
    
    
    
    
    var jsonData = {
        "username": $("#userlogin").html() ,
        "action" : "PROFILE"
    };
    $.ajax({
        url: "php/applicationLayer.php"
        , type: "POST"
        , data: jsonData
        , dataType: "json"
        , contentType: "application/x-www-form-urlencoded"
        , success: function (jsonResponse) {
            
            $("#fNamep").val(jsonResponse.fName);
            $("#lNamep").val(jsonResponse.lName);
            $("#userNamep").val(jsonResponse.userName);
            $("#passwrdp").val(jsonResponse.passwrd);
            
            
        }
        , error: function (errorMessage) {
            
            alert(errorMessage.responseText);
        }
    });
    
    
    
    
    
    
    
    
});



$("#signUpButton").click(function(){
            
           if($("#upEmail").val() == "" | $("#fName").val() == "" | $("#lName").val() == "" | $("#upPassword").val() == ""  ){
               $("#errorMessage5").show();
                      $("#errorMessage5").html("Please fill all the information.");
           }
          else{

             var jsonData = {
                  "usernameRegister" : $("#upEmail").val(),
                  "userPasswordRegister" : $("#upPassword").val(),
                  "fname" : $("#fName").val(),
                  "lname" : $("#lName").val(),
                  
                  "action" : "REGISTER"
              };
           
           
           
           $.ajax({
                  url : "php/applicationLayer.php",
                  type : "POST",
                  data : jsonData,
                  dataType : "json",
                  contentType : "application/x-www-form-urlencoded",
                  success : function(jsonResponse){
                      
                        
                      location.reload();
                      
                      
                  },
                  error : function(errorMessage) {
                      $("#errorMessage5").show();
                      $("#errorMessage5").html("User already exists!");
                     
                  }
              }); 
              
              
          }
              
           
            
});

$("#subcomment").click(function(){
            $("#NoerrorSearch1").hide();
            $("#errorSearch1").hide();
           if($("#mail").val() == "" || $("#comentario").val() == ""){
                            $("#errorSearch1").show();
                            $("#errorSearch1").html("Please write your email and comment.");
            }
            else{
                    var jsonData = {
                          "email" : $("#mail").val(),
                          "comentario" : $("#comentario").val(),

                          "action" : "MAIL"
                      };



                   $.ajax({
                          url : "php/applicationLayer.php",
                          type : "POST",
                          data : jsonData,
                          dataType : "json",
                          contentType : "application/x-www-form-urlencoded",
                          success : function(jsonResponse){

                            $("#NoerrorSearch1").show();
                            $("#NoerrorSearch1").html("Thank You!");

                            $("#mail").val(""); 
                            $("#comentario").val("");  
                          },
                          error : function(errorMessage) {
                              alert("error");

                          }
                      });    
                }    
              
           
            
});








$("#subSearch").click(function () {
    
    $("#errorSearch2").hide();
    
        
    
    resetColor();
    
    var listaPreguntas;
    var preguntaActual = 0;
    var jsonData = {
        "action": "OPCIONMULTIPLESEARCH",
        "question": $("#idSearch").val()
    };
    $.ajax({
        url: "php/applicationLayer.php"
        , type: "POST"
        , data: jsonData
        , dataType: "json"
        , contentType: "application/x-www-form-urlencoded"
        , success: function (jsonResponse) {
            listaPreguntas = jsonResponse;
            console.log(listaPreguntas);
            if(jsonResponse == null){
                $("#errorSearch2").show();
                $("#errorSearch2").html("I'm sorry we couldn't find your question");
            }
            else{
                $("#juegoPreguntasSearch").show();
                $("#search").hide();
                llenaPregunta();
            }
            
            
        }
        , error: function (errorMessage) {
            
        }
    });

    function llenaPregunta() {
        reiniciaOpciones();
        $("#00").html(listaPreguntas[preguntaActual]["pregunta"]);
        var opciones = [listaPreguntas[preguntaActual]["respuesta"], listaPreguntas[preguntaActual]["opcionB"]
                                , listaPreguntas[preguntaActual]["opcionC"], listaPreguntas[preguntaActual]["opcionD"]];
        opciones = shuffleArray(opciones);
        var i = 0;
        $(".opcion1").each(function () {
            if (opciones[i] != "N/A") {
                $(this).html(opciones[i]);
                $(this).show();
            }
            i++;
        });
    }
    $(".opcion1").on("click", function () {
       
        if ($(this).html() == listaPreguntas[preguntaActual]["respuesta"]) {    
            $(this).css("background-color", "#61c76d");
            $("#puntuaje").html(puntosAnteriores); 
            if (preguntaActual < 0) {
                console.log("success!");
               
                preguntaActual++;
                resetColor();
                llenaPregunta();
            }
            else {
                console.log("Se acabo");
                clearTimeout(timerId);
                
                
                
                
            }
        }
        else {
            $('.opcion1').each(function () {
               
                if ($(this).html() == listaPreguntas[preguntaActual]["respuesta"]) {
                    $(this).css("background-color", "#61c76d");
                   
                }
            });
            
            
            
            
            
            $(this).css("background-color", "#db5858");
        }
    });

    function reiniciaOpciones() {
        $(".opcion1").each(function () {
            $(this).hide();
        });
    }
   
    function shuffleArray(a) {
        var i, t, j;
        for (i = a.length - 1; i > 0; i -= 1) {
            t = a[i];
            j = Math.floor(Math.random() * (i + 1));
            a[i] = a[j];
            a[j] = t;
        }
        return a;
    }
});




$("#logoutbutton").click(function () {
        
    var jsonData = {
       
        "action" : "LOGOUT"
    };
    $.ajax({
        url: "php/applicationLayer.php"
        , type: "POST"
        , data: jsonData
        , dataType: "json"
        , contentType: "application/x-www-form-urlencoded"
        , success: function (jsonResponse) {
            
          
            window.location.href = "http://gonzalogtz.com/Content/FinalWeb/"
            
        }
        , error: function (errorMessage) {
            
            alert(errorMessage.responseText);
        }
    });
    
    
    
    
    
    
    
    
});








$('#signUpButton').click(function() {

    
     
});



$('#linkSingUp').click(function() {

        
    $("#signInDiv").hide();
    $("#signOutDiv").show();
     
});

$('#linkSingUp').click(function() {

        
    $("#signInDiv").hide();
    $("#signOutDiv").show();
     
});

$('#botonHigh').click(function() {
        
        $("#pantallaPrincipal").hide();
        $("#juegoPreguntas").hide();
        $("#startGameLabel2").hide();
        $("#tablaPuntajes").show();
        $("#highlab").show();
        $("#comment").hide();
        $("#profile").hide();
        $("#search").hide();
        $("#juegoPreguntasSearch").hide();
        $("#NoerrorSearch").hide();
        $("#errorSearch").hide();
        $("#NoerrorSearch1").hide();
        $("#errorSearch1").hide();
        $("#errorSearch2").hide();
        clearTimeout(timerId);
        $("#NoerrorSearch1").hide();
        $("#timeleft").hide();
        $("#subirPuntaje").hide();
});

$('#contactmeLab').click(function() {
        $("#NoerrorSearch").hide();
        $("#pantallaPrincipal").hide();
        $("#juegoPreguntas").hide();
        $("#startGameLabel2").hide();
        $("#tablaPuntajes").hide();
        $("#comment").show();
        $("#profile").hide();
        $("#highlab").hide();
        $("#search").hide();
        $("#juegoPreguntasSearch").hide();
        $("#NoerrorSearch").hide();
        $("#errorSearch").hide();
        $("#NoerrorSearch1").hide();
        $("#errorSearch1").hide();
        $("#errorSearch2").hide();
        clearTimeout(timerId);
        $("#timeleft").hide();
        $("#NoerrorSearch1").hide();
        $("#subirPuntaje").hide();
     
});

$('#botonProf').click(function() {
        
        $("#pantallaPrincipal").hide();
        $("#juegoPreguntas").hide();
        $("#startGameLabel2").hide();
        $("#tablaPuntajes").hide();
        $("#comment").hide();
        $("#profile").show();
        $("#highlab").hide();
        $("#search").hide();
        $("#juegoPreguntasSearch").hide();
        $("#NoerrorSearch").hide();
        $("#errorSearch").hide();
        $("#NoerrorSearch1").hide();
        $("#errorSearch1").hide();
        $("#errorSearch2").hide();
        clearTimeout(timerId);
        $("#timeleft").hide();
        $("#NoerrorSearch1").hide();
        $("#subirPuntaje").hide();
});

$('#botonPlay').click(function() {
        
        $("#pantallaPrincipal").show();
        $("#juegoPreguntas").hide();
        $("#startGameLabel2").hide();
        $("#tablaPuntajes").hide();
        $("#comment").hide();
        $("#profile").hide();
        $("#search").hide();
        $("#highlab").hide();
        $("#juegoPreguntasSearch").hide();
        $("#NoerrorSearch").hide();
        $("#errorSearch").hide();
        $("#NoerrorSearch1").hide();
        $("#errorSearch1").hide();
        $("#errorSearch2").hide();
        clearTimeout(timerId);
        $("#timeleft").hide();
        $("#NoerrorSearch1").hide();
        $("#subirPuntaje").hide();
        window.location.href = "http://gonzalogtz.com/Content/FinalWeb/gameScreen.php"
});

$('#seachbutton').click(function() {
        
        $("#pantallaPrincipal").hide();
        $("#juegoPreguntas").hide();
        $("#startGameLabel2").hide();
        $("#tablaPuntajes").hide();
        $("#comment").hide();
        $("#profile").hide();
        $("#highlab").hide();
        $("#search").show();
        $("#juegoPreguntasSearch").hide();
        $("#NoerrorSearch").hide();
        $("#errorSearch").hide();
        $("#NoerrorSearch1").hide();
        $("#errorSearch1").hide();
        $("#errorSearch2").hide();
        clearTimeout(timerId);
        $("#timeleft").hide();
        $("#subirPuntaje").hide();
        $("#NoerrorSearch1").hide();
       
});





